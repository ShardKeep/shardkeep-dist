/**
 * ShardKeep — Content Script
 *
 * Injected into every web page. Detects login forms and handles
 * autofill requests from the popup.
 *
 * Phase 1 (PoC): Basic form detection + fill from popup command.
 * Phase 2: Auto-detect on page load, offer to save new passwords.
 */

// ─── Listen for fill commands from popup/background ───
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === 'FILL') {
    fillCredentials(message.username, message.password);
    sendResponse({ ok: true });
  }
});

/**
 * Find login form fields and fill them.
 * Looks for common patterns: input[type=email], input[type=text] near
 * a password field, and input[type=password].
 */
function fillCredentials(username, password) {
  // Find password fields
  const passwordFields = document.querySelectorAll(
    'input[type="password"]:not([hidden]):not([aria-hidden="true"])'
  );

  if (passwordFields.length === 0) {
    console.log('[ShardKeep] No password fields found on this page');
    return;
  }

  // For each password field, find the associated username field
  passwordFields.forEach(passField => {
    // Look for the closest username/email field before the password field
    const form = passField.closest('form') || document.body;
    const inputs = Array.from(form.querySelectorAll(
      'input[type="text"], input[type="email"], input[name*="user"], input[name*="email"], input[name*="login"], input[autocomplete*="username"], input[autocomplete*="email"]'
    ));

    // Find the username field closest to (and before) the password field
    let usernameField = null;
    for (const input of inputs) {
      if (input.compareDocumentPosition(passField) & Node.DOCUMENT_POSITION_FOLLOWING) {
        usernameField = input;
      }
    }

    // Fill the fields
    if (usernameField && username) {
      setNativeValue(usernameField, username);
      usernameField.dispatchEvent(new Event('input', { bubbles: true }));
      usernameField.dispatchEvent(new Event('change', { bubbles: true }));
    }

    if (password) {
      setNativeValue(passField, password);
      passField.dispatchEvent(new Event('input', { bubbles: true }));
      passField.dispatchEvent(new Event('change', { bubbles: true }));
    }
  });

  console.log('[ShardKeep] Credentials filled');
}

/**
 * Set input value using native setter to trigger React/Vue/Angular change detection.
 * Standard input.value = x doesn't work with modern frameworks.
 */
function setNativeValue(element, value) {
  const nativeInputValueSetter = Object.getOwnPropertyDescriptor(
    window.HTMLInputElement.prototype, 'value'
  ).set;
  nativeInputValueSetter.call(element, value);
}

// ─── Wallet bridge for ShardKeep web pages ───
// Pages on master.shardkeep.io can request the connected wallet address
// by dispatching a 'shardkeep-wallet-request' event. The content script
// fetches it from the background worker and responds with 'shardkeep-wallet-response'.
document.addEventListener('shardkeep-wallet-request', () => {
  chrome.runtime.sendMessage({ type: 'GET_VAULT_STATUS' }, (response) => {
    document.dispatchEvent(new CustomEvent('shardkeep-wallet-response', {
      detail: {
        address: (response && response.address) || null,
        nodeId: (response && response.nodeId) || null,
        sentryEnabled: !!(response && response.sentryEnabled),
      }
    }));
  });
});

console.log('[ShardKeep] Content script loaded');
