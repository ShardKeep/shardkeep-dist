/**
 * ShardKeep — Box Keys, Sealed Box & MEK Map Envelope (Team Vaults · T-A/T-B/T-C/T-F)
 *
 * Pure-JS asymmetric "sealed box", wallet-derived encryption keys, and the
 * per-vault MEK map envelope — built on tweetnacl (X25519 + XSalsa20-Poly1305)
 * and native WebCrypto (HKDF, AES-GCM). NO wasm — works in the browser AND in
 * an MV3 extension without the 'wasm-unsafe-eval' CSP relaxation.
 *
 * Sealing/opening happens ENTIRELY client-side (the server only ever stores the
 * sealed blob and never opens it), so we do not need libsodium byte-compat — we
 * use an internally-consistent anonymous sealed box:
 *
 *     sealed = eph_pub(32) || box(msg, nonce, recipientPk, eph_sec)
 *     nonce  = SHA-512(eph_pub || recipientPk)[0:24]
 *
 * ── SECURITY NOTE ──────────────────────────────────────────────────────────
 * The signature used by deriveBoxKeyPair() / deriveWalletKek() IS secret key
 * material. It MUST stay client-side and NEVER be sent to the server. Only
 * PUBLIC keys and a SEPARATE publish-authorization signature (over the public
 * key) are ever transmitted (see publishMessage / enc-key.php).
 */
(function (factory) {
  var nacl = (typeof globalThis !== 'undefined' && globalThis.nacl) ? globalThis.nacl
           : (typeof window !== 'undefined' && window.nacl) ? window.nacl
           : (typeof require === 'function' ? require('tweetnacl') : null);
  var subtle = (typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.subtle) ? globalThis.crypto.subtle
             : (typeof crypto !== 'undefined' && crypto.subtle) ? crypto.subtle
             : (typeof require === 'function' ? require('crypto').webcrypto.subtle : null);
  var rng = (typeof globalThis !== 'undefined' && globalThis.crypto && globalThis.crypto.getRandomValues)
             ? globalThis.crypto : (typeof crypto !== 'undefined' ? crypto : require('crypto').webcrypto);
  var api = factory(nacl, subtle, rng);
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  if (typeof window !== 'undefined') window.ShardKeepBoxKeys = api;
})(function (nacl, subtle, rng) {
  'use strict';
  var te = new TextEncoder();
  var ENVELOPE_FMT = 2; // shard-map envelope format marker (v1 'direct' has no such prefix)

  function concat(a, b) { var o = new Uint8Array(a.length + b.length); o.set(a, 0); o.set(b, a.length); return o; }

  // ── base64 (standard, padded — matches PHP base64_decode/base64_encode) ──
  function toB64(bytes) {
    if (typeof btoa !== 'undefined') { var s = ''; for (var i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]); return btoa(s); }
    return Buffer.from(bytes).toString('base64');
  }
  function fromB64(b64) {
    if (typeof atob !== 'undefined') { var s = atob(b64), o = new Uint8Array(s.length); for (var i = 0; i < s.length; i++) o[i] = s.charCodeAt(i); return o; }
    return new Uint8Array(Buffer.from(b64, 'base64'));
  }
  function toHex(bytes) { var s = ''; for (var i = 0; i < bytes.length; i++) s += bytes[i].toString(16).padStart(2, '0'); return s; }

  // ── HKDF-SHA256(ikm) → len bytes, domain-separated by an info string ──
  async function hkdf(ikm, info, len) {
    var key = await subtle.importKey('raw', ikm, 'HKDF', false, ['deriveBits']);
    var bits = await subtle.deriveBits({ name: 'HKDF', hash: 'SHA-256', salt: new Uint8Array(0), info: te.encode(info) }, key, len * 8);
    return new Uint8Array(bits);
  }

  // ── Derive a deterministic X25519 keypair from a wallet signature (T-B) ──
  //    signatureBytes = 64-byte Ed25519 signature over boxKeyMessage(). SECRET.
  async function deriveBoxKeyPair(signatureBytes, purpose) {
    var seed = await hkdf(signatureBytes, 'shardkeep-box-seal:' + (purpose || 'share'), 32);
    return nacl.box.keyPair.fromSecretKey(seed); // { publicKey(32), secretKey(32) }
  }

  // ── Canonical messages the wallet signs. Keep byte-identical to the server. ──
  function boxKeyMessage(wallet, purpose) {
    return 'ShardKeep — vault sharing key\nWallet: ' + wallet + '\nPurpose: box-seal-v1:' + (purpose || 'share');
  }
  function publishMessage(wallet, purpose, encPkB64) {
    return 'ShardKeep — publish enc key\nWallet: ' + wallet + '\nPurpose: ' + (purpose || 'share') + '\nKey: ' + encPkB64;
  }

  // ── Anonymous sealed box: seal to a recipient's public key (T-C / T-F) ──
  function seal(message, recipientPk) {
    var eph = nacl.box.keyPair();
    var nonce = nacl.hash(concat(eph.publicKey, recipientPk)).subarray(0, 24);
    var c = nacl.box(message, nonce, recipientPk, eph.secretKey);
    return concat(eph.publicKey, c);
  }
  function sealOpen(sealed, recipientPk, recipientSk) {
    if (!sealed || sealed.length < 32 + 16) return null;
    var epk = sealed.subarray(0, 32);
    var c = sealed.subarray(32);
    var nonce = nacl.hash(concat(epk, recipientPk)).subarray(0, 24);
    return nacl.box.open(c, nonce, epk, recipientSk); // Uint8Array | null
  }

  // ── Symmetric wrap of a key under a wallet-KEK (Decision C), AES-256-GCM ──
  async function deriveWalletKek(signatureBytes, context) {
    return hkdf(signatureBytes, 'shardkeep-wallet-kek:' + context, 32);
  }
  async function aesWrap(kek, plaintext) {
    var key = await subtle.importKey('raw', kek, 'AES-GCM', false, ['encrypt']);
    var iv = rng.getRandomValues(new Uint8Array(12));
    var ct = new Uint8Array(await subtle.encrypt({ name: 'AES-GCM', iv: iv }, key, plaintext));
    return { iv: iv, ciphertext: ct }; // WebCrypto appends the 16-byte GCM tag to ciphertext
  }
  async function aesUnwrap(kek, iv, ciphertext) {
    var key = await subtle.importKey('raw', kek, 'AES-GCM', false, ['decrypt']);
    return new Uint8Array(await subtle.decrypt({ name: 'AES-GCM', iv: iv }, key, ciphertext));
  }

  // ── Team-vault shard-map envelope, format v2 (T-A) ──────────────────────────
  //    The shard map is encrypted under the per-vault MEK (32 random bytes), not
  //    under a wallet-derived key. Packed blob: [fmt:1=0x02][iv:12][ct+tag:N].
  //    Personal vaults keep the v1 'direct' path in shardkeep-crypto.js (untouched).
  async function encryptMapV2(mapObj, mek) {
    var key = await subtle.importKey('raw', mek, 'AES-GCM', false, ['encrypt']);
    var iv = rng.getRandomValues(new Uint8Array(12));
    var ct = new Uint8Array(await subtle.encrypt({ name: 'AES-GCM', iv: iv }, key, te.encode(JSON.stringify(mapObj))));
    var packed = new Uint8Array(1 + 12 + ct.length);
    packed[0] = ENVELOPE_FMT; packed.set(iv, 1); packed.set(ct, 13);
    return toB64(packed);
  }
  async function decryptMapV2(b64, mek) {
    var packed = fromB64(b64);
    if (packed.length < 1 + 12 + 16 || packed[0] !== ENVELOPE_FMT) throw new Error('not an envelope-v2 map blob');
    var iv = packed.subarray(1, 13), ct = packed.subarray(13);
    var key = await subtle.importKey('raw', mek, 'AES-GCM', false, ['decrypt']);
    var pt = await subtle.decrypt({ name: 'AES-GCM', iv: iv }, key, ct);
    return JSON.parse(new TextDecoder().decode(pt));
  }

  // ── Entry version history (T-E): content commitment + canonical signed message ──
  async function sha256Hex(bytes) {
    var d = new Uint8Array(await subtle.digest('SHA-256', bytes));
    return toHex(d);
  }
  // Canonical message the author's wallet signs for each entry version. Byte-identical
  // to vault-history.php::entryVersionMessage(). Every field is a stored column, so any
  // version's signature is independently re-verifiable from the ledger forever.
  // prevHashHex '' → 'none' (genesis version).
  function entryVersionMessage(vaultUid, entryId, versionNo, contentHashHex, prevHashHex) {
    return 'ShardKeep — vault entry version\n'
      + 'Vault: ' + vaultUid + '\n'
      + 'Entry: ' + entryId + '\n'
      + 'Version: ' + versionNo + '\n'
      + 'ContentHash: ' + contentHashHex + '\n'
      + 'Prev: ' + (prevHashHex && prevHashHex.length ? prevHashHex : 'none');
  }

  // ── Fresh random 32-byte MEK ──
  function randomMek() { return rng.getRandomValues(new Uint8Array(32)); }

  return {
    deriveBoxKeyPair: deriveBoxKeyPair, boxKeyMessage: boxKeyMessage, publishMessage: publishMessage,
    seal: seal, sealOpen: sealOpen,
    deriveWalletKek: deriveWalletKek, aesWrap: aesWrap, aesUnwrap: aesUnwrap,
    encryptMapV2: encryptMapV2, decryptMapV2: decryptMapV2, randomMek: randomMek,
    sha256Hex: sha256Hex, entryVersionMessage: entryVersionMessage,
    toB64: toB64, fromB64: fromB64, toHex: toHex, concat: concat,
  };
});
