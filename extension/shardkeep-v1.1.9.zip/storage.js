/**
 * ShardKeep — Storage Engine
 *
 * Two storage tiers:
 *   1. Quick Store — encrypted passwords stored as cNFTs on Solana (fast, 25 max)
 *   2. Vault — Shamir-sharded across Bastion nodes, shard map as cNFT (operator-blind)
 *
 * All API calls go through the ShardKeep operator server.
 */

const SHARD_API = 'https://master.shardkeep.io/shardkeep/operator/api/shards.php';
const QUICK_STORE_API = 'https://master.shardkeep.io/shardkeep/operator/api/quick-store.php';
const EXT_SHARED_READ_API = 'https://master.shardkeep.io/shardkeep/operator/api/ext-shared-read.php';

const StorageEngine = {

  // ─── Quick Store (cNFT + database) ───

  /**
   * List all Quick Store entries + Vault entry count for a wallet.
   */
  async quickStoreList(walletAddress) {
    try {
      const resp = await fetch(QUICK_STORE_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'list', wallet_address: walletAddress }),
      });
      if (!resp.ok) return { success: false, error: `HTTP ${resp.status}` };
      const data = await resp.json();
      return {
        success: data.ok,
        entries: data.entries || [],
        quick_count: data.quick_count || 0,
        quick_limit: data.quick_limit || 25,
        vault_entries: data.vault_entries || [],
        vault_count: data.vault_count || 0,
        vault_limit: data.vault_limit,
        error: data.error,
      };
    } catch (e) {
      return { success: false, error: e.message };
    }
  },

  /**
   * Move a Quick Store entry to Vault (shard system).
   */
  async quickStoreMoveToVault(walletAddress, entryId, assetId, secretBase64, site, username) {
    try {
      const resp = await fetch(QUICK_STORE_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'move-to-vault',
          wallet_address: walletAddress,
          entry_id: entryId,
          asset_id: assetId,
          secret: secretBase64,
          site: site || '',
          username: username || '',
        }),
      });
      if (!resp.ok) return { success: false, error: `HTTP ${resp.status}` };
      const data = await resp.json();
      return {
        success: data.ok,
        entry_id: data.entry_id,
        vault_asset_id: data.vault_asset_id,
        shard_count: data.shard_count,
        threshold: data.threshold,
        error: data.error,
      };
    } catch (e) {
      return { success: false, error: e.message };
    }
  },

  // ─── Shared Vaults (Team Vaults) — READ ONLY ───

  /**
   * List the wallet's shared (team) vaults + their current entries, all as
   * ciphertext. Signature-gated (Option A): authSigHex is the "unlock vault"
   * signature the extension already holds from connect — the server re-verifies
   * it. The caller decrypts client-side (unwrap MEK with the team-vault KEK, then
   * decryptMapV2 each entry). READ ONLY — no create/edit/delete here.
   */
  async sharedVaultRead(walletAddress, authSigHex) {
    try {
      const resp = await fetch(EXT_SHARED_READ_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ wallet_address: walletAddress, auth_sig: authSigHex }),
      });
      if (!resp.ok) {
        let err = `HTTP ${resp.status}`;
        try { const j = await resp.json(); if (j && j.error) err = j.error; } catch (e) {}
        return { success: false, error: err, status: resp.status };
      }
      const data = await resp.json();
      return { success: !!data.ok, vaults: data.vaults || [], error: data.error };
    } catch (e) {
      return { success: false, error: e.message };
    }
  },

  // ─── Vault (Shard system + cNFT maps) ───

  /**
   * Get shard map for a vault entry.
   */
  async shardGetMap(entryId, walletAddress) {
    try {
      const resp = await fetch(SHARD_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'get-shard-map', entry_id: entryId, wallet_address: walletAddress }),
      });
      if (!resp.ok) return { success: false, error: `HTTP ${resp.status}` };
      const data = await resp.json();
      return { success: data.ok, shardMap: data.shard_map || null, cnft: data.cnft || null, error: data.error };
    } catch (e) {
      return { success: false, error: e.message };
    }
  },

  /**
   * Retrieve a sharded secret from Bastion nodes.
   */
  async shardRetrieve(entryId, walletAddress) {
    try {
      const resp = await fetch(SHARD_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'retrieve', entry_id: entryId, wallet_address: walletAddress }),
      });
      if (!resp.ok) return { success: false, error: `HTTP ${resp.status}` };
      const data = await resp.json();
      if (data.ok && data.secret) {
        return { success: true, data: atob(data.secret), source: 'vault' };
      }
      return { success: false, error: data.error || 'Retrieval failed' };
    } catch (e) {
      return { success: false, error: e.message };
    }
  },

  /**
   * Delete shards and burn cNFT shard map.
   */
  async shardDelete(entryId, walletAddress) {
    try {
      const resp = await fetch(SHARD_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'delete', entry_id: entryId, wallet_address: walletAddress }),
      });
      if (!resp.ok) return { success: false, error: `HTTP ${resp.status}` };
      const data = await resp.json();
      return { success: data.ok, shardsMarked: data.shards_marked || 0, error: data.error };
    } catch (e) {
      return { success: false, error: e.message };
    }
  },

  // ─── Encrypted Vault Operations ───

  /**
   * Move/copy Quick Store entry to Vault with client-side map encryption (2-step).
   * Falls back to legacy flow if ShardKeepCrypto is unavailable.
   */
  async quickStoreMoveToVaultEncrypted(walletAddress, entryId, assetId, secretBase64, site, username, keyMaterial, action) {
    action = action || 'move-to-vault';
    try {
      // Step 1: Distribute shards, get plaintext map
      const resp = await fetch(QUICK_STORE_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: action,
          wallet_address: walletAddress,
          entry_id: entryId,
          asset_id: assetId,
          secret: secretBase64,
          site: site || '',
          username: username || '',
          client_encryption: true,
        }),
      });
      if (!resp.ok) return { success: false, error: `HTTP ${resp.status}` };
      const data = await resp.json();
      if (!data.ok || !data.needs_seal) return { success: data.ok, error: data.error };

      // Step 2: Encrypt map and seal
      const encryptedMapB64 = await ShardKeepCrypto.encryptShardMapForStorage(
        data.shard_map, keyMaterial
      );
      const sealResp = await fetch(SHARD_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'seal-map',
          entry_id: data.vault_entry_id,
          wallet_address: walletAddress,
          encrypted_map: encryptedMapB64,
          site: site || '',
          username: username || '',
        }),
      });
      if (!sealResp.ok) return { success: false, error: `HTTP ${sealResp.status}` };
      const sealData = await sealResp.json();

      // Step 3: If move, delete source QS entry
      if (data.delete_source && assetId) {
        await fetch(QUICK_STORE_API, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'delete', entry_id: entryId, wallet_address: walletAddress, asset_id: assetId }),
        });
      }

      return {
        success: sealData.ok,
        entry_id: entryId,
        vault_asset_id: sealData.cnft?.nft_asset_id,
        error: sealData.error,
      };
    } catch (e) {
      return { success: false, error: e.message };
    }
  },

  /**
   * Retrieve a vault secret with encrypted map support.
   * Tries server-side first, falls back to client-side map decryption.
   */
  async shardRetrieveEncrypted(entryId, walletAddress, keyMaterial) {
    try {
      // Try normal retrieve first (works for legacy plaintext maps)
      let resp = await fetch(SHARD_API, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ action: 'retrieve', entry_id: entryId, wallet_address: walletAddress }),
      });
      if (!resp.ok) return { success: false, error: `HTTP ${resp.status}` };
      let data = await resp.json();
      if (data.ok) return { success: true, data: atob(data.secret), source: 'vault' };

      // If encrypted map, decrypt and retry with node locations
      if (data.needs_client_map && keyMaterial) {
        const mapResult = await this.shardGetMap(entryId, walletAddress);
        if (!mapResult.success) return { success: false, error: 'Map fetch failed: ' + mapResult.error };

        const mapObj = await ShardKeepCrypto.decryptShardMapFromStorage(mapResult.shardMap, keyMaterial);
        const nodeMap = {};
        for (const [hash, info] of Object.entries(mapObj)) {
          nodeMap[hash] = info.node_id;
        }

        resp = await fetch(SHARD_API, {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'retrieve', entry_id: entryId, wallet_address: walletAddress, node_map: nodeMap }),
        });
        if (!resp.ok) return { success: false, error: `HTTP ${resp.status}` };
        data = await resp.json();
        if (data.ok) return { success: true, data: atob(data.secret), source: 'vault' };
      }

      return { success: false, error: data.error || 'Retrieval failed' };
    } catch (e) {
      return { success: false, error: e.message };
    }
  },
};
