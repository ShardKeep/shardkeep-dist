/**
 * ShardKeep — Browser Extension PoC
 *
 * Phase 1: Local storage with Web Crypto API encryption.
 * Wallet-derived encryption key via Phantom signature.
 * Solana on-chain storage comes in Phase 2.
 */

// ─── Debug Logger ───
const DEBUG = true;
const debugLog = [];

function log(category, message, data = null) {
  const ts = new Date().toISOString().split('T')[1].slice(0, 12);
  const entry = { ts, category, message, data };
  debugLog.push(entry);

  // Console output
  const prefix = `[ShardKeep ${category.toUpperCase()}]`;
  if (data) {
    console.log(`${prefix} ${message}`, data);
  } else {
    console.log(`${prefix} ${message}`);
  }

  // Update debug panel if visible
  if (DEBUG && document.getElementById('debugPanel')) {
    renderDebugPanel();
  }

  // Persist to chrome.storage for cross-session review
  if (debugLog.length % 5 === 0) {
    chrome.storage.local.set({ shardkeep_debug_log: debugLog.slice(-200) });
  }
}

function renderDebugPanel() {
  const panel = document.getElementById('debugOutput');
  if (!panel) return;
  panel.innerHTML = debugLog.map(e => {
    const catColors = {
      init: '#4EA1FF',
      wallet: '#a78bfa',
      crypto: '#f43f5e',
      vault: '#22c55e',
      storage: '#f59e0b',
      ui: '#7a8599',
      error: '#ef4444',
    };
    const color = catColors[e.category] || '#7a8599';
    let line = `<span style="color:#4a5568">${e.ts}</span> <span style="color:${color};font-weight:600">[${e.category.toUpperCase()}]</span> ${escapeHtml(e.message)}`;
    if (e.data) {
      let dataStr;
      try {
        dataStr = typeof e.data === 'string' ? e.data : JSON.stringify(e.data, null, 0);
        if (dataStr.length > 120) dataStr = dataStr.slice(0, 120) + '...';
      } catch { dataStr = String(e.data); }
      line += ` <span style="color:#4a5568">${escapeHtml(dataStr)}</span>`;
    }
    return line;
  }).join('\n');
  panel.scrollTop = panel.scrollHeight;
}

// ─── State ───
let isConnected = false;
let walletAddress = null;
/**
 * ═══ PBKDF2 Salt Registry ═══
 *
 * Each vault entry stores the salt version (`sv` field) used to derive its
 * encryption key. New salts are ADDED with new version numbers — never
 * deleted. CURRENT_SALT_VERSION is bumped when rotating.
 *
 * Version history:
 *   1 — shardkeep-v1 — ShardKeep launch salt
 *
 * Entries WITHOUT a valid `sv` field — whether missing, null, or referencing
 * an unknown version — are REJECTED. No implicit fallback. Rotation safety
 * depends on every entry self-identifying its salt version.
 */
const SALT_REGISTRY = Object.freeze({
    1: 'shardkeep-v1',
});
const CURRENT_SALT_VERSION = 1;

let walletAddressForKey = null;      // the full key material string keys were derived from (pubkey|sig)
const keyCache = new Map();          // Map<saltVersion, CryptoKey>
let encryptionKey = null;             // CryptoKey @ CURRENT_SALT_VERSION (shortcut for new entries)
let vault = []; // Array of {id, site, username, encryptedPassword, iv, createdAt}
let quickStoreEntries = []; // Entries from Quick Store API (cNFT-backed)
let vaultEntries = [];      // Entries in Vault (shard-backed)
let quickStoreCount = 0;
let quickStoreLimit = 25;
let vaultCount = 0;
let vaultLimit = 20; // pawn default; updated from server
let activeDebugTab = 'wallet';
const sentryLog = [];

// ─── DOM Elements ───
const viewConnect = document.getElementById('viewConnect');
const viewVault = document.getElementById('viewVault');
const viewAdd = document.getElementById('viewAdd');
const walletStatus = document.getElementById('walletStatus');
const vaultList = document.getElementById('vaultList');
const vaultCountEl = document.getElementById('vaultCount');
const searchInput = document.getElementById('searchInput');
const toast = document.getElementById('toast');

// ─── Version Check UI ───
async function updateVersionStatus() {
  const versionLabel = document.getElementById('versionLabel');
  const nodeIndicator = document.getElementById('nodeIndicator');

  // Request fresh version check from background worker
  chrome.runtime.sendMessage({ type: 'FORCE_VERSION_CHECK' }, (versionCheck) => {
    if (!versionCheck) {
      log('init', 'No version check data available');
      nodeIndicator.className = 'node-indicator offline';
      nodeIndicator.title = 'Sentry: not connected';
      return;
    }

    log('init', 'Version check received', versionCheck);

    // Determine version gap
    const currentParts = (versionCheck.wallet_version || '0.0.0').split('.').map(Number);
    const serverParts = (versionCheck.server_wallet_version || '0.0.0').split('.').map(Number);
    const versionsBehind = (serverParts[0] - currentParts[0]) * 100 + (serverParts[1] - currentParts[1]) * 10 + (serverParts[2] - currentParts[2]);

    // Update node indicator dot based on version health
    if (versionsBehind <= 0) {
      nodeIndicator.className = 'node-indicator current';
      nodeIndicator.title = 'Version current';
    } else if (versionsBehind <= 10) {
      nodeIndicator.className = 'node-indicator behind-1';
      nodeIndicator.title = 'Update available — 1 version behind';
    } else {
      nodeIndicator.className = 'node-indicator behind-2';
      nodeIndicator.title = 'Update required — 2+ versions behind (rewards gated)';
    }

    // Update version label
    if (versionCheck.wallet_update_available) {
      // Rebuild inner HTML to preserve the dot
      versionLabel.innerHTML = '<span class="node-indicator ' + nodeIndicator.className.split(' ')[1] + '"></span>v' + versionCheck.wallet_version + ' → Update';
      versionLabel.classList.add('update-available');
      versionLabel.onclick = () => {
        if (versionCheck.wallet_download_url) {
          chrome.tabs.create({ url: 'https://master.shardkeep.io' + versionCheck.wallet_download_url });
          showToast('Download started — unzip and reload extension');
        }
      };
      log('init', 'Wallet update available', {
        current: versionCheck.wallet_version,
        latest: versionCheck.server_wallet_version,
        versionsBehind
      });
    } else {
      versionLabel.innerHTML = '<span class="node-indicator current"></span>v' + versionCheck.wallet_version;
      versionLabel.classList.remove('update-available');
      versionLabel.onclick = null;
    }

    // Log node status
    const qualStatus = versionCheck.qualification_status || 'unknown';
    log('init', `Sentry status: ${qualStatus}, node: ${versionCheck.node_id || 'unknown'}`, {
      reward_eligible: versionCheck.reward_eligible,
      wallet_current: !versionCheck.wallet_update_available,
      versionsBehind,
    });
  });
}

// ─── Initialization ───
document.addEventListener('DOMContentLoaded', async () => {
  log('init', 'Extension popup opened');

  // Paint the version label from the manifest immediately so no stale value
  // is ever visible while we wait for the server version-check round-trip.
  const extVersion = chrome.runtime.getManifest().version;
  const versionLabelEl = document.getElementById('versionLabel');
  if (versionLabelEl) {
    versionLabelEl.innerHTML = '<span class="node-indicator" id="nodeIndicator"></span>v' + extVersion;
  }

  // Check version status with operator (overwrites above if server reports differently)
  updateVersionStatus();

  // Load previous debug log
  const prevLog = await chrome.storage.local.get(['shardkeep_debug_log']);
  if (prevLog.shardkeep_debug_log) {
    debugLog.push(...prevLog.shardkeep_debug_log);
    log('init', `Loaded ${prevLog.shardkeep_debug_log.length} previous log entries`);
  }

  // Check if we have a stored session.
  // Identity (walletPubkey) lives in chrome.storage.local — survives browser restart.
  // Secret (walletSignature) lives in chrome.storage.session — in-memory only,
  // cleared on browser restart so user must re-sign to unlock their vault.
  const localStored = await chrome.storage.local.get(['walletPubkey', 'walletName']);
  const sessionStored = await chrome.storage.session.get(['walletSignature']);

  if (localStored.walletPubkey && sessionStored.walletSignature) {
    walletAddress = localStored.walletPubkey;
    log('init', 'Restoring session from stored pubkey + signature', {
      pubkey: walletAddress,
      wallet: localStored.walletName || 'unknown'
    });
    await deriveKeyFromPubkeyAndSignature(walletAddress, sessionStored.walletSignature);
    const vaultData = await chrome.storage.local.get(['vault_' + walletAddress]);
    vault = vaultData['vault_' + walletAddress] || [];
    log('storage', `Loaded ${vault.length} vault entries`, { key: 'vault_' + walletAddress });
    showVault();
    // Status dots update from real API responses
  } else if (localStored.walletPubkey) {
    // Pubkey remembered but signature was cleared (browser restart) — prompt to re-sign
    log('init', 'Known wallet, session expired — re-sign required', { pubkey: localStored.walletPubkey });
    showToast('Session expired — please reconnect to unlock vault');
    // Leave the connect view visible; user clicks connect, signs, vault comes back
  } else {
    log('init', 'No stored session — showing connect view');
  }
});

// ─── Wallet Connection (Solana Wallet Standard — supports every compliant wallet) ───
document.getElementById('btnConnect').addEventListener('click', async () => {
  log('wallet', 'Connect button clicked — opening wallet picker tab');
  await openWalletConnectTab();
});

/**
 * Opens the dedicated connect page (https://master.shardkeep.io/solace/wallet-connect.html)
 * in a new tab. Hosted on a real HTTPS URL because wallet extensions (Phantom,
 * Solflare, Backpack, etc.) only inject themselves into http(s) pages, not into
 * chrome-extension:// origins. The extension ID is passed in the query string
 * so the page can send the signed result back via chrome.runtime.sendMessage.
 */
async function openWalletConnectTab() {
  const extId = chrome.runtime.id;
  const url = `https://master.shardkeep.io/shardkeep/wallet-connect.html?extId=${encodeURIComponent(extId)}`;
  await chrome.tabs.create({ url });
  showToast('Opened wallet picker — complete in the new tab');
}

/**
 * The background service worker receives the external wallet_connected message
 * from the connect page (via chrome.runtime.onMessageExternal) and persists
 * pubkey to storage.local + signature to storage.session.
 *
 * If the popup is STILL OPEN when signing completes, background sends us a
 * 'wallet_ready' ping — we reload from storage immediately.
 * If the popup was closed (typical), we pick up the stored data when user
 * reopens the popup (see DOMContentLoaded handler below).
 */
chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg && msg.type === 'wallet_ready') {
    log('wallet', `Wallet ready via ${msg.walletName}`, { pubkey: msg.pubkey });
    loadSessionAndShowVault().then(() => sendResponse({ ok: true }));
    return true;
  }
});

/**
 * Read walletPubkey from storage.local + walletSignature from storage.session,
 * derive the encryption key, load the vault, and show it.
 * Called both on popup open AND when background pushes 'wallet_ready'.
 */
async function loadSessionAndShowVault() {
  const localStored = await chrome.storage.local.get(['walletPubkey', 'walletName']);
  const sessionStored = await chrome.storage.session.get(['walletSignature']);
  if (!localStored.walletPubkey || !sessionStored.walletSignature) return false;
  walletAddress = localStored.walletPubkey;
  await deriveKeyFromPubkeyAndSignature(walletAddress, sessionStored.walletSignature);
  const vaultData = await chrome.storage.local.get(['vault_' + walletAddress]);
  vault = vaultData['vault_' + walletAddress] || [];
  log('storage', `Loaded ${vault.length} vault entries`, { key: 'vault_' + walletAddress });
  showVault();
  showToast(`Connected via ${localStored.walletName || 'wallet'}`);
  // Status dots update from real API responses
  return true;
}

// handleWalletConnected() obsolete — background service worker now handles the
// external message and persists to storage. Popup reads via loadSessionAndShowVault().

// ─── Key Derivation ───
/**
 * Derive one AES-256-GCM key for a specific salt version.
 * Results are cached in keyCache keyed by salt version.
 * Called by deriveKeyFromPubkeyAndSignature() below, and on-demand for legacy entries.
 */
async function deriveKeyForSaltVersion(address, saltVersion) {
  if (!(saltVersion in SALT_REGISTRY)) {
    throw new Error(`Unknown salt version: ${saltVersion}`);
  }
  // If we already have this version cached for this address, reuse
  if (walletAddressForKey === address && keyCache.has(saltVersion)) {
    return keyCache.get(saltVersion);
  }

  const encoder = new TextEncoder();
  const keyMaterial = await crypto.subtle.importKey(
    'raw', encoder.encode(address), 'PBKDF2', false, ['deriveKey']
  );
  const key = await crypto.subtle.deriveKey(
    {
      name: 'PBKDF2',
      salt: encoder.encode(SALT_REGISTRY[saltVersion]),
      iterations: 100000,
      hash: 'SHA-256'
    },
    keyMaterial,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
  keyCache.set(saltVersion, key);
  return key;
}

/**
 * Derive encryption key from wallet pubkey + signature.
 * Key material is the string `<pubkey_base58>|<signature_hex>`.
 *
 * Why both inputs:
 *  - pubkey alone is public info; anyone knowing your address could derive the key
 *  - signature alone is harder to produce but doesn't bind the key to an identity
 *  - combining them means an attacker needs BOTH (pubkey is trivial to get, but
 *    producing the signature requires the private key)
 *
 * The signature is deterministic for the same message → reproducible across
 * devices (user signs the same canonical message anywhere, gets same bytes,
 * gets same key → same vault decrypts on any device).
 */
async function deriveKeyFromPubkeyAndSignature(pubkeyBase58, signatureHex) {
  const startTime = performance.now();
  const keyMaterial = pubkeyBase58 + '|' + signatureHex;

  // Cache identity = full key material (pubkey|signature). If the material
  // changes (e.g. re-sign), clear the cache and re-derive all salt versions.
  if (walletAddressForKey !== keyMaterial) {
    keyCache.clear();
    walletAddressForKey = keyMaterial;
  }

  encryptionKey = await deriveKeyForSaltVersion(keyMaterial, CURRENT_SALT_VERSION);

  const elapsed = (performance.now() - startTime).toFixed(1);
  log('crypto', `Key derived in ${elapsed}ms`, {
    algorithm: 'AES-256-GCM',
    kdf: 'PBKDF2-SHA256',
    iterations: 100000,
    saltVersion: CURRENT_SALT_VERSION,
    derivationTime: elapsed + 'ms'
  });
}

// ─── Encryption ───
/**
 * Encrypt plaintext with the CURRENT salt version's key.
 * Returns { data, iv, sv } — sv = salt version tag stored on the entry.
 */
async function encryptPassword(plaintext) {
  const startTime = performance.now();
  const encoder = new TextEncoder();
  const iv = crypto.getRandomValues(new Uint8Array(12));
  log('crypto', 'Encrypting password', {
    plaintextLength: plaintext.length,
    iv: Array.from(iv.slice(0, 4)).map(b => b.toString(16).padStart(2, '0')).join('') + '...',
    algorithm: 'AES-256-GCM',
    saltVersion: CURRENT_SALT_VERSION
  });

  const encrypted = await crypto.subtle.encrypt(
    { name: 'AES-GCM', iv },
    encryptionKey,
    encoder.encode(plaintext)
  );

  const result = {
    data: Array.from(new Uint8Array(encrypted)),
    iv: Array.from(iv),
    sv: CURRENT_SALT_VERSION
  };

  const elapsed = (performance.now() - startTime).toFixed(2);
  log('crypto', `Encryption complete in ${elapsed}ms`, {
    ciphertextLength: result.data.length,
    encryptionTime: elapsed + 'ms',
    saltVersion: result.sv
  });
  return result;
}

/**
 * Decrypt ciphertext using the salt version it was encrypted with.
 * REJECTS entries with missing/unknown `sv` — no implicit fallback.
 *
 * @param {number[]} encData  ciphertext bytes
 * @param {number[]} iv       12-byte IV
 * @param {number}   sv       salt version tag from the entry
 * @returns {Promise<string>} plaintext
 * @throws  {Error}           if sv is missing or not in SALT_REGISTRY
 */
async function decryptPassword(encData, iv, sv) {
  const startTime = performance.now();
  if (typeof sv !== 'number' || !(sv in SALT_REGISTRY)) {
    throw new Error(`incompatible_entry: missing/unknown salt version (sv=${sv})`);
  }
  log('crypto', 'Decrypting password', {
    ciphertextLength: encData.length,
    algorithm: 'AES-256-GCM',
    saltVersion: sv,
    saltName: SALT_REGISTRY[sv]
  });

  const key = await deriveKeyForSaltVersion(walletAddressForKey, sv);

  const decrypted = await crypto.subtle.decrypt(
    { name: 'AES-GCM', iv: new Uint8Array(iv) },
    key,
    new Uint8Array(encData)
  );
  const plaintext = new TextDecoder().decode(decrypted);

  const elapsed = (performance.now() - startTime).toFixed(2);
  log('crypto', `Decryption complete in ${elapsed}ms`, {
    plaintextLength: plaintext.length,
    decryptionTime: elapsed + 'ms',
    saltVersion: sv,
    needsReencryption: sv !== CURRENT_SALT_VERSION
  });
  return plaintext;
}

// ─── Vault Operations ───

/**
 * Save a new password entry.
 * @param {string} destination - 'quick_store' | 'vault' | 'both'
 */
async function saveEntry(site, username, password, destination) {
  log('vault', `Saving new entry: ${site} / ${username} → ${destination}`);

  const encrypted = await encryptPassword(password);
  const entryId = Date.now().toString(36) + Math.random().toString(36).slice(2, 6);
  const encB64 = btoa(String.fromCharCode(...encrypted.data));
  const ivB64 = btoa(String.fromCharCode(...encrypted.iv));

  const entry = {
    id: entryId,
    site: site,
    username: username,
    encryptedPassword: encrypted.data,
    iv: encrypted.iv,
    sv: encrypted.sv,
    createdAt: new Date().toISOString(),
    source: destination === 'vault' ? 'vault' : 'quick_store',
    assetId: null,
  };

  const saveToQs = destination === 'quick_store' || destination === 'both';
  const saveToVault = destination === 'vault' || destination === 'both';

  // ─── Quick Store ───
  if (saveToQs) {
    const resp = await fetch('https://master.shardkeep.io/shardkeep/operator/api/quick-store.php', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        action: 'store',
        wallet_address: walletAddress,
        entry_id: entryId,
        site: site,
        username: username,
        encrypted_data: encB64,
        iv: ivB64,
      }),
    });
    const result = await resp.json();
    if (result.ok) {
      entry.assetId = result.asset_id || null;
      quickStoreCount = result.count || quickStoreCount + 1;
      log('storage', 'Quick Store: entry saved', { asset_id: result.asset_id, count: result.count });
    } else {
      throw new Error('Quick Store: ' + (result.error || 'unknown'));
    }
  }

  // ─── Vault (Shamir sharded) ───
  if (saveToVault) {
    const secretPayload = JSON.stringify({ encrypted: encB64, iv: ivB64, sv: encrypted.sv });
    const secretBase64 = btoa(secretPayload);

    const result = await StorageEngine.quickStoreMoveToVaultEncrypted(
      walletAddress, entryId, null, secretBase64, site, username,
      walletAddressForKey, 'copy-to-vault'
    );
    if (!result.success) {
      throw new Error('Vault: ' + (result.error || 'unknown'));
    }
    entry.source = 'vault';
    entry.vaultAssetId = result.vault_asset_id;
    // For vault-only entries, use the server's vault id so syncFromVault won't duplicate
    if (destination === 'vault') entry.id = entryId + '-vault';
    vaultCount++;
    log('storage', 'Vault: entry sharded', { asset_id: result.vault_asset_id });
  }

  // Local cache (always)
  vault.push(entry);
  await persistVault();
  updateStorageStatus();

  log('vault', 'Entry saved', {
    id: entry.id, site: entry.site, source: entry.source, destination,
    totalEntries: vault.length
  });

  return entry;
}

async function deleteEntry(id) {
  const entry = vault.find(e => e.id === id);
  log('vault', `Deleting entry`, { id, site: entry?.site });

  // Delete from Quick Store API (burns cNFT + removes from database)
  if (entry && entry.source === 'quick_store') {
    try {
      await fetch('https://master.shardkeep.io/shardkeep/operator/api/quick-store.php', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          action: 'delete',
          entry_id: id,
          wallet_address: walletAddress,
          asset_id: entry.assetId || null,
        }),
      });
      quickStoreCount = Math.max(0, quickStoreCount - 1);
      log('storage', 'Quick Store: entry deleted from server + cNFT burned');
    } catch (e) {
      log('error', 'Quick Store delete failed (local still removed)', { error: e.message });
    }
  }

  // Delete from Vault API (burns cNFT shard map + marks shards for deletion)
  if (entry && entry.source === 'vault') {
    try {
      await StorageEngine.shardDelete(id, walletAddress);
      vaultCount = Math.max(0, vaultCount - 1);
      log('storage', 'Vault: shards marked for deletion + cNFT burned');
    } catch (e) {
      log('error', 'Vault delete failed', { error: e.message });
    }
  }

  // Remove locally
  vault = vault.filter(e => e.id !== id);
  await persistVault();
  updateStorageStatus();
  log('vault', `Entry deleted, ${vault.length} entries remaining`);
}

async function persistVault() {
  const startTime = performance.now();
  const storageKey = 'vault_' + walletAddress;
  const dataSize = JSON.stringify(vault).length;

  await chrome.storage.local.set({ [storageKey]: vault });

  const elapsed = (performance.now() - startTime).toFixed(1);
  log('storage', `Vault persisted to chrome.storage.local`, {
    key: storageKey,
    entries: vault.length,
    sizeBytes: dataSize,
    sizeKB: (dataSize / 1024).toFixed(1) + 'KB',
    writeTime: elapsed + 'ms'
  });
}

// ─── Storage Status ───
function updateTierDot(tier, status) {
  // Map old tier names to new dot IDs
  const dotMap = { solana: 'QuickStore', shards: 'Vault', local: 'QuickStore' };
  const dotId = dotMap[tier] || tier.charAt(0).toUpperCase() + tier.slice(1);
  const dot = document.getElementById('dot' + dotId);
  if (!dot) return;
  dot.className = 'tier-dot ' + status;
}

function updateStorageStatus() {
  const qsDot = document.getElementById('dotQuickStore');
  const vDot = document.getElementById('dotVault');
  const qsLabel = document.getElementById('qsCount');
  const vLabel = document.getElementById('vaultCountBadge');

  if (qsDot) qsDot.className = 'tier-dot ' + (quickStoreCount > 0 ? 'synced' : 'ready');
  if (vDot) vDot.className = 'tier-dot ' + (vaultCount > 0 ? 'synced' : 'ready');
  if (qsLabel) qsLabel.textContent = quickStoreCount + '/' + quickStoreLimit;
  if (vLabel) vLabel.textContent = vaultCount > 0 ? vaultCount : '';
}

// ─── Quick Store + Vault Sync ───

/**
 * Sync Quick Store entries from the cNFT API.
 * Fetches all entries, merges any missing into local vault, and updates
 * the quickStoreEntries list for rendering. Non-blocking.
 */
async function syncFromQuickStore() {
  if (!walletAddress) return;
  try {
    const result = await StorageEngine.quickStoreList(walletAddress);
    if (!result.success) {
      log('sync', 'Quick Store sync: unavailable', { error: result.error });
      updateStorageStatus();
      return;
    }

    quickStoreEntries = result.entries || [];
    quickStoreCount = result.quick_count || 0;
    quickStoreLimit = result.quick_limit || 25;
    vaultCount = result.vault_count || 0;
    if (result.vault_limit !== undefined) vaultLimit = result.vault_limit;

    // Merge any server entries missing from local vault
    const localIds = new Set(vault.map(e => e.id));
    let added = 0;

    for (const entry of quickStoreEntries) {
      const id = entry.entry_id;
      if (!localIds.has(id)) {
        // Server returns encrypted_data and iv as base64 strings (MySQL TO_BASE64).
        // Convert back to byte arrays so decryptPassword() can use them.
        let encBytes = entry.encrypted_data || '';
        let ivBytes = entry.iv || '';
        if (typeof encBytes === 'string' && encBytes.length > 0) {
          try { encBytes = Array.from(atob(encBytes), c => c.charCodeAt(0)); } catch (e) { /* keep as-is */ }
        }
        if (typeof ivBytes === 'string' && ivBytes.length > 0) {
          try { ivBytes = Array.from(atob(ivBytes), c => c.charCodeAt(0)); } catch (e) { /* keep as-is */ }
        }
        vault.push({
          id,
          site: entry.site || id,
          username: entry.username || '',
          encryptedPassword: encBytes,
          iv: ivBytes,
          sv: CURRENT_SALT_VERSION,
          createdAt: entry.created_at || new Date().toISOString(),
          source: 'quick_store',
          assetId: entry.asset_id || null,
        });
        added++;
      } else {
        // Update asset_id and source on existing local entries
        const local = vault.find(e => e.id === id);
        if (local) {
          local.source = 'quick_store';
          local.assetId = entry.asset_id || local.assetId;
        }
      }
    }

    if (added > 0) {
      await persistVault();
      log('sync', `Quick Store sync: merged ${added} new entries`, {
        remote: quickStoreEntries.length,
        local: vault.length,
        added,
      });
    } else {
      log('sync', `Quick Store sync: up to date (${quickStoreEntries.length} entries)`);
    }

    updateStorageStatus();
    renderVaultList();
  } catch (e) {
    log('error', 'Quick Store sync failed', { error: e.message });
    updateStorageStatus();
  }
}

/**
 * Sync Vault entries from server. The quickStoreList API returns vault_entries
 * alongside Quick Store entries. Merge any server vault entries missing locally.
 */
async function syncFromVault() {
  if (!walletAddress) return;
  try {
    const result = await StorageEngine.quickStoreList(walletAddress);
    if (!result.success) {
      log('sync', 'Vault sync: unavailable', { error: result.error });
      updateStorageStatus();
      return;
    }

    const serverVault = result.vault_entries || [];
    vaultCount = result.vault_count || 0;
    if (result.vault_limit !== undefined) vaultLimit = result.vault_limit;

    // Merge server vault entries missing from local vault.
    // Server vault entry_ids have a '-vault' suffix (e.g., "foo-vault").
    // Local entries from Quick Store use the base id ("foo").
    // We use the FULL server id (with -vault) for vault entries locally
    // so QS and vault entries coexist when an entry is in both tiers.
    const localIds = new Set(vault.map(e => e.id));
    let added = 0;

    for (const entry of serverVault) {
      const vaultId = entry.entry_id; // e.g., "foo-vault"

      if (!localIds.has(vaultId)) {
        vault.push({
          id: vaultId,
          site: entry.site || vaultId,
          username: entry.username || '',
          encryptedPassword: [],
          iv: [],
          sv: CURRENT_SALT_VERSION,
          createdAt: entry.created_at || new Date().toISOString(),
          source: 'vault',
          assetId: null,
          vaultAssetId: entry.asset_id || null,
          securityTier: entry.security_tier || 'pawn',
          shardCount: entry.shard_count || 0,
          threshold: entry.threshold || 0,
        });
        added++;
      } else {
        // Update metadata on existing vault entry (don't touch source)
        const local = vault.find(e => e.id === vaultId);
        if (local) {
          local.vaultAssetId = entry.asset_id || local.vaultAssetId;
          local.site = entry.site || local.site;
          local.username = entry.username || local.username;
        }
      }
    }

    if (added > 0) {
      await persistVault();
      log('sync', `Vault sync: merged ${added} new entries from server`, {
        remote: serverVault.length,
        local: vault.filter(e => e.source === 'vault').length,
        added,
      });
    } else {
      log('sync', `Vault sync: up to date (${serverVault.length} server, ${vault.filter(e => e.source === 'vault').length} local)`);
    }

    vaultEntries = vault.filter(e => e.source === 'vault');
    updateStorageStatus();
    renderVaultList();
  } catch (e) {
    log('error', 'Vault sync failed', { error: e.message });
    updateStorageStatus();
  }
}

/**
 * Move a Quick Store entry to the Vault (shard system).
 * Sends encrypted data to the API, which shards it across Bastion nodes
 * and burns the Quick Store cNFT.
 */
async function moveToVault(entryId, assetId) {
  if (!walletAddress) return;

  const entry = vault.find(e => e.id === entryId);
  if (!entry) {
    showToast('Entry not found', true);
    return;
  }

  log('vault', `Moving entry to Vault: ${entry.site}`, { entryId, assetId });
  showToast('Moving to Vault...');

  try {
    // Build the secret payload — convert byte arrays to base64 first
    const encData = Array.isArray(entry.encryptedPassword)
      ? btoa(String.fromCharCode(...entry.encryptedPassword))
      : entry.encryptedPassword;
    const ivData = Array.isArray(entry.iv)
      ? btoa(String.fromCharCode(...entry.iv))
      : entry.iv;
    const secretPayload = JSON.stringify({ encrypted: encData, iv: ivData, sv: entry.sv });
    const secretBase64 = btoa(secretPayload);

    const result = await StorageEngine.quickStoreMoveToVault(
      walletAddress, entryId, assetId, secretBase64, entry.site, entry.username
    );

    if (!result.success) {
      showToast('Move failed: ' + (result.error || 'Unknown error'), true);
      log('error', 'Move to Vault failed', { entryId, error: result.error });
      return;
    }

    // Update local entry: tag as vault source
    entry.source = 'vault';
    entry.vaultAssetId = result.vault_asset_id;
    delete entry.assetId; // No longer a Quick Store cNFT
    await persistVault();

    // Refresh both sections
    await syncFromQuickStore();
    await syncFromVault();

    showToast('Moved to Vault — sharded across network');
    log('vault', `Entry moved to Vault successfully`, {
      entryId,
      site: entry.site,
      shardCount: result.shard_count,
      threshold: result.threshold,
    });
  } catch (e) {
    showToast('Move failed: ' + e.message, true);
    log('error', 'Move to Vault exception', { entryId, error: e.message });
  }
}

// ─── UI Rendering ───
function showVault() {
  isConnected = true;
  viewConnect.classList.add('hidden');
  viewVault.classList.remove('hidden');
  walletStatus.className = 'status connected';
  walletStatus.innerHTML = '<span class="addr-text">' +
    walletAddress.slice(0, 4) + '...' + walletAddress.slice(-4) + '</span>';
  walletStatus.title = 'Click to disconnect wallet';
  renderVaultList();
  log('ui', 'Vault view displayed', { address: walletAddress, entries: vault.length });

  // Sync from Quick Store + Vault in background
  syncFromQuickStore();
  syncFromVault();
}

function showConnectView() {
  isConnected = false;
  walletAddress = null;
  vault = [];
  encryptionKey = null;
  keyCache.clear();
  walletAddressForKey = null;
  viewConnect.classList.remove('hidden');
  viewVault.classList.add('hidden');
  walletStatus.className = 'status disconnected';
  walletStatus.textContent = 'DISCONNECTED';
  walletStatus.title = '';
}

async function disconnectWallet() {
  if (!confirm('Disconnect wallet and lock your vault?')) return;
  log('wallet', 'Disconnecting wallet');
  // Clear storage via background (keeps all code paths in sync)
  await new Promise((r) => chrome.runtime.sendMessage({ type: 'DISCONNECT' }, r));
  showConnectView();
  showToast('Wallet disconnected');
}

// Wire up the walletStatus badge as a disconnect button when connected
document.getElementById('walletStatus').addEventListener('click', () => {
  if (isConnected) disconnectWallet();
});

function renderVaultList(filter = '') {
  const filterLower = filter.toLowerCase();

  // Separate entries by source
  const qsEntries = vault.filter(e => e.source !== 'vault');
  const vEntries = vault.filter(e => e.source === 'vault');

  // Apply search filter
  const filteredQS = filter
    ? qsEntries.filter(e =>
        e.site.toLowerCase().includes(filterLower) ||
        e.username.toLowerCase().includes(filterLower))
    : qsEntries;

  const filteredV = filter
    ? vEntries.filter(e =>
        e.site.toLowerCase().includes(filterLower) ||
        e.username.toLowerCase().includes(filterLower))
    : vEntries;

  // Update section badges
  const qsBadge = document.getElementById('quickStoreBadge');
  const vBadge = document.getElementById('vaultBadge');
  if (qsBadge) qsBadge.textContent = qsEntries.length + '/' + quickStoreLimit;
  if (vBadge) vBadge.textContent = vEntries.length + (vEntries.length === 1 ? ' entry' : ' entries');

  // Render Quick Store entries
  const qsList = document.getElementById('quickStoreList');
  if (qsList) {
    if (filteredQS.length === 0) {
      qsList.innerHTML = filter && qsEntries.length > 0
        ? '<div class="vault-empty">No matches.</div>'
        : '<div class="vault-empty">No Quick Store entries yet.</div>';
    } else {
      qsList.innerHTML = filteredQS.map(entry => {
        const initial = entry.site.charAt(0).toUpperCase();
        const moveBtn = entry.assetId
          ? `<button class="move-vault-btn" data-action="move-vault" data-id="${escapeHtml(entry.id)}" data-asset="${escapeHtml(entry.assetId)}" title="Move to Vault">&#128737; Vault</button>`
          : '';
        return `
          <div class="vault-item" data-id="${escapeHtml(entry.id)}">
            <div class="site-icon">${initial}</div>
            <div class="site-info">
              <div class="site-name">${siteNameHtml(entry.site)}</div>
              <div class="site-user">${escapeHtml(entry.username)}</div>
            </div>
            ${moveBtn}
            <button class="copy-btn" data-action="copy" data-id="${escapeHtml(entry.id)}" title="Copy password">&#128203;</button>
            <button class="copy-btn" data-action="delete" data-id="${escapeHtml(entry.id)}" title="Delete" style="font-size:12px;">&#10060;</button>
          </div>`;
      }).join('');
    }
  }

  // Render Vault entries
  const vList = document.getElementById('vaultEntryList');
  if (vList) {
    if (filteredV.length === 0) {
      vList.innerHTML = filter && vEntries.length > 0
        ? '<div class="vault-empty">No matches.</div>'
        : '<div class="vault-empty">Move entries from Quick Store for sharded protection.</div>';
    } else {
      vList.innerHTML = filteredV.map(entry => {
        const initial = entry.site.charAt(0).toUpperCase();
        return `
          <div class="vault-item" data-id="${escapeHtml(entry.id)}">
            <div class="site-icon" style="border-color: rgba(139,92,246,0.3); color: var(--purple);">${initial}</div>
            <div class="site-info">
              <div class="site-name"><svg class="vault-badge" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/></svg>${siteNameHtml(entry.site)}</div>
              <div class="site-user">${escapeHtml(entry.username)}</div>
            </div>
            <button class="copy-btn" data-action="copy" data-id="${escapeHtml(entry.id)}" title="Copy password">&#128203;</button>
            <button class="copy-btn" data-action="delete" data-id="${escapeHtml(entry.id)}" title="Delete" style="font-size:12px;">&#10060;</button>
          </div>`;
      }).join('');
    }
  }

  // Handle case where both are empty (no entries at all)
  if (vault.length === 0 && !filter) {
    if (qsList) qsList.innerHTML = '';
    if (vList) vList.innerHTML = '';
    const qsSection = document.getElementById('quickStoreSection');
    if (qsSection) {
      qsSection.querySelector('.vault-empty')?.remove();
      const emptyEl = document.createElement('div');
      emptyEl.className = 'empty-state';
      emptyEl.innerHTML = '<div class="empty-icon">&#128274;</div><p>Your vault is empty.<br>Click <strong>+ Add</strong> to store your first password.</p>';
      if (qsList) qsList.appendChild(emptyEl);
    }
  }

  vaultCountEl.textContent = vault.length + ' password' + (vault.length !== 1 ? 's' : '');
  if (filter) log('ui', `Search filtered: ${filteredQS.length + filteredV.length} of ${vault.length} shown`, { filter });
}

// ─── Event Handlers ───

// ─── Add Form Validation ───
function updateSaveButton() {
  const site = document.getElementById('inputSite').value.trim();
  const username = document.getElementById('inputUser').value.trim();
  const password = document.getElementById('inputPass').value;
  const btn = document.getElementById('btnSave');
  const ready = !!(site && username && password);
  btn.disabled = !ready;
  if (ready) {
    btn.classList.add('btn-ready');
    btn.classList.remove('btn-primary');
  } else {
    btn.classList.remove('btn-ready');
    btn.classList.add('btn-primary');
  }
  console.log('[ShardKeep] Save button state:', { ready, site: !!site, username: !!username, password: !!password, classes: btn.className });
}

document.getElementById('inputSite').addEventListener('input', updateSaveButton);
document.getElementById('inputUser').addEventListener('input', updateSaveButton);
document.getElementById('inputPass').addEventListener('input', updateSaveButton);

// Show add form
document.getElementById('btnShowAdd').addEventListener('click', () => {
  viewAdd.classList.add('active');
  document.getElementById('inputSite').focus();
  updateDestinationOptions();
  updateSaveButton();
  log('ui', 'Add password form opened');
});

// Cancel add
document.getElementById('btnCancelAdd').addEventListener('click', () => {
  viewAdd.classList.remove('active');
  clearAddForm();
  log('ui', 'Add password form cancelled');
});

// Save password
document.getElementById('btnSave').addEventListener('click', async () => {
  const site = document.getElementById('inputSite').value.trim();
  const username = document.getElementById('inputUser').value.trim();
  const password = document.getElementById('inputPass').value;

  if (!site || !username || !password) {
    showToast('Please fill in all fields', true);
    log('vault', 'Save rejected — missing fields', { site: !!site, username: !!username, password: !!password });
    return;
  }

  const btn = document.getElementById('btnSave');
  btn.disabled = true;
  btn.classList.remove('btn-ready');
  btn.classList.add('btn-primary');
  btn.textContent = 'Encrypting...';

  const destRadio = document.querySelector('input[name="storeDest"]:checked');
  const destination = destRadio ? destRadio.value : 'quick_store';

  try {
    const destLabel = destination === 'both' ? 'Quick Store + Vault' : destination === 'vault' ? 'Vault' : 'Quick Store';
    showToast('Encrypting & saving to ' + destLabel + '...');
    await saveEntry(site, username, password, destination);
    renderVaultList();
    viewAdd.classList.remove('active');
    clearAddForm();
    showToast('Saved to ' + destLabel);
  } catch (err) {
    showToast('Failed to save: ' + err.message, true);
    log('error', 'Save failed', { error: err.message });
  } finally {
    btn.textContent = 'Encrypt & Store';
    updateSaveButton();
  }
});

// Search
searchInput.addEventListener('input', (e) => {
  renderVaultList(e.target.value);
});

// Site link clicks — open in new tab
vaultList.addEventListener('click', (e) => {
  const link = e.target.closest('.site-link');
  if (link) {
    e.preventDefault();
    const url = link.dataset.url;
    if (url) chrome.tabs.create({ url });
  }
});

// Copy / Delete actions
vaultList.addEventListener('click', async (e) => {
  const btn = e.target.closest('[data-action]');
  if (!btn) return;

  const id = btn.dataset.id;
  const action = btn.dataset.action;

  if (action === 'copy') {
    const entry = vault.find(e => e.id === id);
    if (!entry) return;
    log('vault', `Copy requested for ${entry.site}`);
    try {
      const password = await decryptPassword(entry.encryptedPassword, entry.iv, entry.sv);
      await navigator.clipboard.writeText(password);
      btn.innerHTML = '&#10004;';
      btn.classList.add('copied');
      showToast('Password copied');
      log('vault', `Password copied to clipboard`, { site: entry.site });
      // Future salt rotations: entries still on an older salt get upgraded on
      // read. For launch (single salt v1), this branch is a no-op.
      if (typeof entry.sv === 'number' && entry.sv !== CURRENT_SALT_VERSION) {
        try {
          const fresh = await encryptPassword(password);
          entry.encryptedPassword = fresh.data;
          entry.iv = fresh.iv;
          entry.sv = fresh.sv;
          entry.reencryptedAt = new Date().toISOString();
          await persistVault();
          log('crypto', `Entry upgraded: salt v${entry.sv} → v${fresh.sv}`, { site: entry.site });
        } catch (reEncErr) {
          log('error', 'Re-encryption failed (non-fatal)', { id, error: reEncErr.message });
        }
      }
      setTimeout(() => {
        btn.innerHTML = '&#128203;';
        btn.classList.remove('copied');
      }, 2000);
    } catch (err) {
      if (String(err.message || '').startsWith('incompatible_entry')) {
        showToast('Entry incompatible — delete and re-create', true);
      } else {
        showToast('Failed to decrypt', true);
      }
      log('error', 'Decryption failed', { id, error: err.message });
    }
  } else if (action === 'move-vault') {
    const assetId = btn.dataset.asset;
    if (!assetId) {
      showToast('No asset ID — cannot move', true);
      return;
    }
    btn.disabled = true;
    btn.textContent = 'Moving...';
    await moveToVault(id, assetId);
  } else if (action === 'delete') {
    if (confirm('Delete this password?')) {
      await deleteEntry(id);
      renderVaultList(searchInput.value);
      showToast('Password deleted');
    }
  }
});

// ─── Debug Panel Toggle ───
document.getElementById('btnDebug')?.addEventListener('click', () => {
  const panel = document.getElementById('debugPanel');
  if (panel.classList.contains('hidden')) {
    panel.classList.remove('hidden');
    renderDebugPanel();
    log('ui', 'Debug panel opened');
  } else {
    panel.classList.add('hidden');
  }
});

document.getElementById('btnDebugClear')?.addEventListener('click', () => {
  if (activeDebugTab === 'wallet') {
    debugLog.length = 0;
    chrome.storage.local.remove(['shardkeep_debug_log']);
  } else {
    sentryLog.length = 0;
  }
  renderDebugPanel();
});

// ─── Debug Tab Switching ───
document.getElementById('debugTabWallet')?.addEventListener('click', function() { switchDebugTab('wallet', this); });
document.getElementById('debugTabSentry')?.addEventListener('click', function() { switchDebugTab('sentry', this); });

function switchDebugTab(tab, el) {
  activeDebugTab = tab;
  document.querySelectorAll('.debug-tab').forEach(t => t.classList.remove('active'));
  el.classList.add('active');
  document.getElementById('debugTabLabel').textContent = tab === 'wallet' ? 'Wallet Log' : 'Sentry Log';
  renderDebugPanel();
}

// Override renderDebugPanel to support tabs
const _origRenderDebug = renderDebugPanel;
renderDebugPanel = function() {
  const panel = document.getElementById('debugOutput');
  if (!panel) return;
  const entries = activeDebugTab === 'wallet' ? debugLog : sentryLog;
  panel.innerHTML = entries.map(e => {
    const catColors = {
      init: '#4EA1FF', wallet: '#a78bfa', crypto: '#f43f5e',
      vault: '#22c55e', storage: '#f59e0b', ui: '#7a8599',
      error: '#ef4444', sentry: '#22c55e', heartbeat: '#00d5ff',
      network: '#a78bfa',
    };
    const color = catColors[e.category] || '#7a8599';
    let line = `<span style="color:#4a5568">${e.ts}</span> <span style="color:${color};font-weight:600">[${e.category.toUpperCase()}]</span> ${escapeHtml(e.message)}`;
    if (e.data) {
      let dataStr;
      try {
        dataStr = typeof e.data === 'string' ? e.data : JSON.stringify(e.data, null, 0);
        if (dataStr.length > 120) dataStr = dataStr.slice(0, 120) + '...';
      } catch { dataStr = String(e.data); }
      line += ` <span style="color:#4a5568">${escapeHtml(dataStr)}</span>`;
    }
    return line;
  }).join('\n');
  panel.scrollTop = panel.scrollHeight;
};

function logSentry(category, message, data = null) {
  const ts = new Date().toISOString().split('T')[1].slice(0, 12);
  sentryLog.push({ ts, category, message, data });
  console.log(`[ShardKeep Sentry ${category.toUpperCase()}] ${message}`, data || '');
  if (activeDebugTab === 'sentry' && document.getElementById('debugPanel') && !document.getElementById('debugPanel').classList.contains('hidden')) {
    renderDebugPanel();
  }
}

// ─── Sentry Toggle ───
document.getElementById('sentryToggle')?.addEventListener('change', async (e) => {
  const enabled = e.target.checked;
  if (enabled) {
    log('ui', 'Sentry toggle ON — starting network participation');
    logSentry('network', 'Sentry activating — sending first heartbeat...');
    chrome.runtime.sendMessage({ type: 'ENABLE_SENTRY' }, (resp) => {
      if (resp && resp.ok) {
        logSentry('network', 'Sentry enabled — heartbeats started');
        updateSentryStatus();
      }
    });
  } else {
    log('ui', 'Sentry toggle OFF — stopping network participation');
    logSentry('network', 'Sentry deactivating...');
    chrome.runtime.sendMessage({ type: 'DISABLE_SENTRY' }, (resp) => {
      if (resp && resp.ok) {
        logSentry('network', 'Sentry disabled — heartbeats stopped');
        updateSentryStatus();
      }
    });
  }
});

// Update Sentry status display
function updateSentryStatus() {
  chrome.runtime.sendMessage({ type: 'GET_SENTRY_STATUS' }, (result) => {
    if (!result) return;

    const toggle = document.getElementById('sentryToggle');
    const stats = document.getElementById('sentryStats');
    const statusEl = document.getElementById('xstatStatus');
    const storageEl = document.getElementById('xstatStorage');
    const heartbeatsEl = document.getElementById('xstatHeartbeats');

    toggle.checked = result.enabled;

    if (result.enabled) {
      stats.classList.remove('sentry-disabled');
      const hb = result.heartbeat || {};
      const qual = hb.qualification_status || 'starting';
      const statusMap = {
        pending:       { text: 'Pending',      icon: '\u23F3', desc: 'Waiting for first heartbeat...', banner: '' },
        evaluating:    { text: 'Evaluating',    icon: '\u23F3', desc: 'Node under evaluation (~30 min)', banner: '' },
        authenticated: { text: 'Authenticated', icon: '\uD83D\uDD11', desc: 'Credentials verified', banner: '' },
        qualified:     { text: 'Qualified',     icon: '\u2728', desc: 'Ready for activation', banner: '' },
        active:        { text: 'Active',        icon: '\u26A1', desc: 'Earning rewards \u2022 Node fully operational', banner: 'status-active' },
        suspended:     { text: 'Suspended',     icon: '\u26D4', desc: 'Node suspended by operator', banner: 'status-suspended' },
        starting:      { text: 'Starting...',   icon: '\u23F3', desc: 'Connecting to network', banner: '' },
      };
      const s = statusMap[qual] || statusMap.starting;

      // Update status banner
      const banner = document.getElementById('sentryStatusBanner');
      const iconEl = document.getElementById('sentryStatusIcon');
      const timerEl = document.getElementById('sentryTimer');
      statusEl.textContent = s.text;
      const descEl = document.getElementById('xstatDesc');
      if (descEl) descEl.textContent = s.desc;
      if (iconEl) iconEl.textContent = s.icon;
      if (banner) {
        banner.className = 'sentry-status-banner visible ' + s.banner;
      }
      if (timerEl) {
        timerEl.textContent = qual === 'active' ? '\u2713' : '';
      }

      storageEl.textContent = (hb.shard_pct || 0) + '%';
      heartbeatsEl.textContent = hb.heartbeat || '0';

      logSentry('heartbeat', `Status: ${s.text}, Storage: ${storageEl.textContent}, Beats: ${heartbeatsEl.textContent}`);
    } else {
      stats.classList.add('sentry-disabled');
      statusEl.textContent = 'Off';
      storageEl.textContent = '0%';
      heartbeatsEl.textContent = '0';
    }
  });
}

// Load Sentry status on popup open
setTimeout(updateSentryStatus, 500);
// Refresh every 10 seconds while popup is open
setInterval(updateSentryStatus, 10000);

// ─── Utilities ───
function clearAddForm() {
  document.getElementById('inputSite').value = '';
  document.getElementById('inputUser').value = '';
  document.getElementById('inputPass').value = '';
  // Reset destination to first available option
  const qsRadio = document.querySelector('input[name="storeDest"][value="quick_store"]');
  if (qsRadio && !qsRadio.disabled) qsRadio.checked = true;
  else {
    const vRadio = document.querySelector('input[name="storeDest"][value="vault"]');
    if (vRadio && !vRadio.disabled) vRadio.checked = true;
  }
  updateSaveButton();
}

function updateDestinationOptions() {
  const qsFull = quickStoreCount >= quickStoreLimit;
  const vaultFull = vaultLimit !== -1 && vaultCount >= vaultLimit; // -1 = unlimited (queen)

  const qsRadio = document.querySelector('input[name="storeDest"][value="quick_store"]');
  const vRadio = document.querySelector('input[name="storeDest"][value="vault"]');
  const bothRadio = document.querySelector('input[name="storeDest"][value="both"]');

  qsRadio.disabled = qsFull;
  vRadio.disabled = vaultFull;
  bothRadio.disabled = qsFull || vaultFull;

  // Show counts
  const qsCountEl = document.getElementById('destQsCount');
  const vCountEl = document.getElementById('destVaultCount');
  if (qsCountEl) qsCountEl.textContent = '(' + quickStoreCount + '/' + quickStoreLimit + ')';
  if (vCountEl) vCountEl.textContent = vaultLimit === -1 ? '(' + vaultCount + ')' : '(' + vaultCount + '/' + vaultLimit + ')';

  // If current selection is disabled, auto-select first available
  const checked = document.querySelector('input[name="storeDest"]:checked');
  if (checked && checked.disabled) {
    if (!vRadio.disabled) vRadio.checked = true;
    else if (!qsRadio.disabled) qsRadio.checked = true;
  }
}

function showToast(message, isError = false) {
  toast.textContent = message;
  toast.className = 'toast show' + (isError ? ' error' : '');
  setTimeout(() => { toast.className = 'toast'; }, 2500);
}

function escapeHtml(str) {
  const div = document.createElement('div');
  div.textContent = str;
  return div.innerHTML;
}

function siteNameHtml(site) {
  const s = escapeHtml(site || '');
  if (!site) return s;
  if (/^[^\s]+\.[^\s]+$/.test(site.trim())) {
    const url = site.startsWith('http') ? escapeHtml(site) : 'https://' + escapeHtml(site.trim());
    return `<a href="#" class="site-link" data-url="${url}">${s}</a>`;
  }
  return s;
}
