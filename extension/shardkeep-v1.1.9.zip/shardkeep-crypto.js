/**
 * ShardKeep — Client-Side Shard Map Encryption
 *
 * AES-256-GCM encryption for shard maps using wallet-derived keys.
 * The server never sees the decryption key — only the wallet holder
 * can decrypt shard maps to learn where their shards are stored.
 *
 * Key derivation:
 *   1. Wallet signs a fixed canonical message (no timestamp → stable key)
 *   2. Key material = "pubkeyBase58|signatureHex"
 *   3. PBKDF2-SHA256 (100k iterations) with versioned salt → AES-256-GCM key
 *
 * Storage format (packed binary, stored in shardkeep_shard_maps.encrypted_map):
 *   [iv: 12 bytes] [sv: 1 byte (salt version)] [ciphertext: N bytes]
 *
 * Works in both browser <script> and Chrome extension contexts.
 */
const ShardKeepCrypto = (function() {
    'use strict';

    // ─── Salt Registry (separate from password salts) ───
    const MAP_SALT_REGISTRY = Object.freeze({
        1: 'shardkeep-map-v1',
    });
    const CURRENT_MAP_SALT_VERSION = 1;

    // Canonical message for map key signing (fixed, never changes)
    const MAP_KEY_MESSAGE_PREFIX = 'ShardKeep \u2014 shard map key\nAddress: ';
    const MAP_KEY_MESSAGE_SUFFIX = '\nPurpose: persistent';

    // ─── Internal key cache ───
    let _cachedKeyMaterial = null;
    const _keyCache = new Map(); // saltVersion → CryptoKey

    /**
     * Build the canonical signing message for map key derivation.
     * @param {string} pubkeyBase58
     * @returns {string}
     */
    function buildMapKeyMessage(pubkeyBase58) {
        return MAP_KEY_MESSAGE_PREFIX + pubkeyBase58 + MAP_KEY_MESSAGE_SUFFIX;
    }

    /**
     * Derive an AES-256-GCM key for map encryption.
     * @param {string} keyMaterial - "pubkeyBase58|signatureHex"
     * @param {number} saltVersion - version from MAP_SALT_REGISTRY
     * @returns {Promise<CryptoKey>}
     */
    async function deriveMapKey(keyMaterial, saltVersion) {
        if (!MAP_SALT_REGISTRY[saltVersion]) {
            throw new Error('Unknown map salt version: ' + saltVersion);
        }

        // Invalidate cache if key material changed
        if (_cachedKeyMaterial !== keyMaterial) {
            _keyCache.clear();
            _cachedKeyMaterial = keyMaterial;
        }
        if (_keyCache.has(saltVersion)) {
            return _keyCache.get(saltVersion);
        }

        const encoder = new TextEncoder();
        const rawKey = await crypto.subtle.importKey(
            'raw', encoder.encode(keyMaterial), 'PBKDF2', false, ['deriveKey']
        );
        const key = await crypto.subtle.deriveKey(
            {
                name: 'PBKDF2',
                salt: encoder.encode(MAP_SALT_REGISTRY[saltVersion]),
                iterations: 100000,
                hash: 'SHA-256',
            },
            rawKey,
            { name: 'AES-GCM', length: 256 },
            false,
            ['encrypt', 'decrypt']
        );
        _keyCache.set(saltVersion, key);
        return key;
    }

    /**
     * Pack encrypted map components into a single binary blob.
     * Format: [iv: 12 bytes] [sv: 1 byte] [ciphertext: N bytes]
     * @param {Uint8Array} iv - 12-byte initialization vector
     * @param {number} sv - salt version (0-255)
     * @param {Uint8Array} ciphertext - AES-GCM ciphertext + auth tag
     * @returns {Uint8Array}
     */
    function packEncryptedMap(iv, sv, ciphertext) {
        const packed = new Uint8Array(12 + 1 + ciphertext.byteLength);
        packed.set(iv, 0);
        packed[12] = sv & 0xFF;
        packed.set(new Uint8Array(ciphertext), 13);
        return packed;
    }

    /**
     * Unpack a stored encrypted map blob into components.
     * @param {Uint8Array} packed
     * @returns {{iv: Uint8Array, sv: number, ciphertext: Uint8Array}}
     */
    function unpackEncryptedMap(packed) {
        if (packed.length < 14) {
            throw new Error('Encrypted map too short (' + packed.length + ' bytes)');
        }
        return {
            iv: packed.slice(0, 12),
            sv: packed[12],
            ciphertext: packed.slice(13),
        };
    }

    /**
     * Encrypt a shard map object for storage.
     * @param {object} mapObj - Plaintext shard map {hash: {node_id, index}}
     * @param {string} keyMaterial - "pubkeyBase58|signatureHex"
     * @returns {Promise<string>} base64 of packed encrypted blob
     */
    async function encryptShardMapForStorage(mapObj, keyMaterial) {
        const sv = CURRENT_MAP_SALT_VERSION;
        const key = await deriveMapKey(keyMaterial, sv);
        const iv = crypto.getRandomValues(new Uint8Array(12));
        const plaintext = new TextEncoder().encode(JSON.stringify(mapObj));
        const ciphertext = await crypto.subtle.encrypt(
            { name: 'AES-GCM', iv: iv },
            key,
            plaintext
        );
        const packed = packEncryptedMap(iv, sv, new Uint8Array(ciphertext));
        return uint8ToBase64(packed);
    }

    /**
     * Decrypt a stored encrypted map blob.
     * @param {string} encryptedMapB64 - base64 of packed encrypted blob
     * @param {string} keyMaterial - "pubkeyBase58|signatureHex"
     * @returns {Promise<object>} plaintext map object
     */
    async function decryptShardMapFromStorage(encryptedMapB64, keyMaterial) {
        const packed = base64ToUint8(encryptedMapB64);
        const { iv, sv, ciphertext } = unpackEncryptedMap(packed);
        if (!MAP_SALT_REGISTRY[sv]) {
            throw new Error('Unknown map salt version in encrypted blob: ' + sv);
        }
        const key = await deriveMapKey(keyMaterial, sv);
        const plaintext = await crypto.subtle.decrypt(
            { name: 'AES-GCM', iv: iv },
            key,
            ciphertext
        );
        return JSON.parse(new TextDecoder().decode(plaintext));
    }

    // ─── Base64 helpers (browser-safe, no atob/btoa for binary) ───

    function uint8ToBase64(bytes) {
        let binary = '';
        for (let i = 0; i < bytes.length; i++) {
            binary += String.fromCharCode(bytes[i]);
        }
        return btoa(binary);
    }

    function base64ToUint8(b64) {
        const binary = atob(b64);
        const bytes = new Uint8Array(binary.length);
        for (let i = 0; i < binary.length; i++) {
            bytes[i] = binary.charCodeAt(i);
        }
        return bytes;
    }

    // ─── Public API ───
    return {
        MAP_SALT_REGISTRY: MAP_SALT_REGISTRY,
        CURRENT_MAP_SALT_VERSION: CURRENT_MAP_SALT_VERSION,
        buildMapKeyMessage: buildMapKeyMessage,
        deriveMapKey: deriveMapKey,
        encryptShardMapForStorage: encryptShardMapForStorage,
        decryptShardMapFromStorage: decryptShardMapFromStorage,
        packEncryptedMap: packEncryptedMap,
        unpackEncryptedMap: unpackEncryptedMap,
    };
})();

if (typeof window !== 'undefined') window.ShardKeepCrypto = ShardKeepCrypto;
if (typeof module !== 'undefined') module.exports = ShardKeepCrypto;
