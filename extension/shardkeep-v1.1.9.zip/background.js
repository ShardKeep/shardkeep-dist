/**
 * ShardKeep — Background Service Worker
 *
 * Dual-purpose:
 * 1. Vault support — version checks, message passing
 * 2. Sentry (when enabled) — heartbeats, shard storage, network participation
 *
 * The Sentry is permanently type "sentry" — cannot be upgraded to bastion or warden.
 * Browser extensions are lightweight sentry nodes only.
 */

const OPERATOR_URL = 'https://master.shardkeep.io/shardkeep/operator/api/version-check.php';
const HEARTBEAT_URL = 'https://master.shardkeep.io/shardkeep/operator/api/heartbeat.php';
const RECOVER_URL = 'https://master.shardkeep.io/shardkeep/operator/api/recover-node.php';
// Version is the single source of truth: manifest.json → chrome.runtime.getManifest().version
// Both WALLET_VERSION and SENTRY_VERSION are the same value (same extension, same codebase).
const WALLET_VERSION = chrome.runtime.getManifest().version;
const SENTRY_VERSION = chrome.runtime.getManifest().version;
const HEARTBEAT_INTERVAL_MIN = 0.5; // 30 seconds in minutes
const NODE_TYPE = 'sentry'; // LOCKED — extension nodes cannot be vault or operator
const NETWORK = 'testnet';
const SHARD_STORAGE_LIMIT = 25 * 1024 * 1024; // 25MB in bytes

let nodeId = null;
let apiKey = null;
let pendingVerifyResult = null;
let sentryEnabled = false;

// ─── Wallet Connect bridge ───
// Listens for signed-message results from https://master.shardkeep.io/shardkeep/wallet-connect.html
// (allowed via manifest.externally_connectable). The popup is closed while the
// user is signing in the new tab, so the listener MUST live here in the
// background service worker. We persist the result to storage so the popup
// can pick it up when it reopens, AND we forward a push to the popup if it's
// still alive via chrome.runtime.sendMessage.
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'wallet_connected') return false;

  // Security: only accept from the expected origin
  if (!sender.url || !sender.url.startsWith('https://master.shardkeep.io/shardkeep/wallet-connect.html')) {
    console.warn('[ShardKeep] Rejected wallet_connected from unexpected origin:', sender.url);
    sendResponse({ ok: false, error: 'untrusted_origin' });
    return true;
  }

  console.log('[ShardKeep BG] wallet_connected received from', msg.walletName, 'pubkey', msg.pubkey);

  (async () => {
    try {
      // Persist pubkey to local storage (identity, survives restart)
      await chrome.storage.local.set({
        walletPubkey: msg.pubkey,
        walletName: msg.walletName,
        walletConnectedAt: msg.timestamp,
      });
      // Persist signatures to session storage (memory-only, cleared on browser restart)
      const sessionData = { walletSignature: msg.signature };
      if (msg.mapSignature) sessionData.walletMapSignature = msg.mapSignature;
      await chrome.storage.session.set(sessionData);

      // Attempt wallet-based node recovery (if storage was wiped by a browser update,
      // the user reconnects their wallet and we can reclaim the old node identity)
      const recovered = await attemptWalletRecovery();

      // Register wallet→node mapping on server (via version check)
      try {
        await checkVersion();
      } catch (e) { /* non-fatal */ }

      // Try to push to popup if it's open — non-fatal if it isn't
      try {
        chrome.runtime.sendMessage({
          type: 'wallet_ready',
          pubkey: msg.pubkey,
          walletName: msg.walletName,
          recovered: recovered,
        });
      } catch (e) { /* popup closed, that's expected */ }

      // Close the connect tab
      if (sender.tab && sender.tab.id) {
        try { chrome.tabs.remove(sender.tab.id); } catch (e) {}
      }

      sendResponse({ ok: true, recovered: recovered });
    } catch (err) {
      console.error('[ShardKeep BG] wallet_connected handler failed:', err);
      sendResponse({ ok: false, error: err.message });
    }
  })();

  return true; // keep sendResponse alive for async
});

// ─── Shared Vaults unlock bridge ───
// Second, separate signature from the same wallet-connect page (mode=teamvault):
// the team-vault key that HKDF-derives the MEK-wrap KEK. It is SECRET (never sent
// to any server), so it lives ONLY in session storage (cleared on browser restart).
chrome.runtime.onMessageExternal.addListener((msg, sender, sendResponse) => {
  if (!msg || msg.type !== 'team_vault_unlocked') return false;

  if (!sender.url || !sender.url.startsWith('https://master.shardkeep.io/shardkeep/wallet-connect.html')) {
    console.warn('[ShardKeep] Rejected team_vault_unlocked from unexpected origin:', sender.url);
    sendResponse({ ok: false, error: 'untrusted_origin' });
    return true;
  }

  (async () => {
    try {
      await chrome.storage.session.set({
        teamVaultSignature: msg.tvSignature,
        teamVaultPubkey: msg.pubkey,
      });
      console.log('[ShardKeep BG] team_vault_unlocked for', msg.pubkey);
      try { chrome.runtime.sendMessage({ type: 'team_vault_ready', pubkey: msg.pubkey }); } catch (e) {}
      if (sender.tab && sender.tab.id) { try { chrome.tabs.remove(sender.tab.id); } catch (e) {} }
      sendResponse({ ok: true });
    } catch (err) {
      console.error('[ShardKeep BG] team_vault_unlocked handler failed:', err);
      sendResponse({ ok: false, error: err.message });
    }
  })();

  return true; // keep sendResponse alive for async
});

// ─── Startup ───
chrome.runtime.onInstalled.addListener(() => {
  console.log('[ShardKeep] Extension installed/updated');
  setTimeout(init, 100);
});

chrome.runtime.onStartup.addListener(() => {
  console.log('[ShardKeep] Browser started');
  setTimeout(init, 100);
});

// Delayed init for service worker wake-up
setTimeout(init, 200);

/**
 * One-time migration: copy legacy storage keys → shardkeep_* equivalents.
 * Handles both exnus_* (v0.1–0.5) and citadel_* (v0.6–0.8) key prefixes.
 * Idempotent — only copies when shardkeep_* keys are absent.
 */
async function migrateLegacyStorageKeys() {
  const newKeys = ['shardkeep_node_id', 'shardkeep_api_key', 'shardkeep_sentry_enabled', 'shardkeep_shards', 'shardkeep_debug_log'];
  const cur = await chrome.storage.local.get(newKeys);

  // Try citadel_* first (most recent legacy), then exnus_* (oldest)
  const legacyPrefixes = [
    ['citadel_node_id', 'citadel_api_key', 'citadel_xnode_enabled', 'citadel_shards', 'citadel_debug_log'],
    ['exnus_node_id', 'exnus_api_key', 'exnus_xnode_enabled', 'exnus_shards', 'exnus_debug_log'],
  ];

  for (const oldKeys of legacyPrefixes) {
    const old = await chrome.storage.local.get(oldKeys);
    const updates = {};
    for (let i = 0; i < oldKeys.length; i++) {
      if (old[oldKeys[i]] !== undefined && cur[newKeys[i]] === undefined) {
        updates[newKeys[i]] = old[oldKeys[i]];
        console.log(`[ShardKeep] Migrating ${oldKeys[i]} → ${newKeys[i]}`);
      }
    }
    if (Object.keys(updates).length > 0) {
      await chrome.storage.local.set(updates);
      console.log(`[ShardKeep] Migration complete: ${Object.keys(updates).length} keys copied`);
      break; // Don't overwrite with older prefix
    }
  }
}

async function init() {
  try {
    await migrateLegacyStorageKeys();
    const stored = await chrome.storage.local.get(['shardkeep_node_id', 'shardkeep_api_key', 'shardkeep_sentry_enabled']);

    if (stored.shardkeep_node_id) {
      nodeId = stored.shardkeep_node_id;
    } else {
      // No stored node_id — generate a temporary one.
      // If a wallet is connected, we'll attempt recovery after version check.
      nodeId = 'ext-' + chrome.runtime.id.substring(0, 8) + '-' + Date.now().toString(36);
      await chrome.storage.local.set({ shardkeep_node_id: nodeId });
      console.log('[ShardKeep] Generated new node_id (storage was empty)');
    }

    if (stored.shardkeep_api_key) {
      apiKey = stored.shardkeep_api_key;
    }

    sentryEnabled = !!stored.shardkeep_sentry_enabled;

    console.log(`[ShardKeep] Node: ${nodeId}, Sentry: ${sentryEnabled ? 'ACTIVE' : 'off'}, Key: ${apiKey ? 'loaded' : 'none'}`);

    // Do initial version check (don't let failure block startup)
    try {
      await checkVersion();
    } catch (e) {
      console.warn('[ShardKeep] Version check failed on init:', e.message);
    }

    // If we just generated a fresh node_id (no prior stored id), attempt wallet-based recovery
    if (!stored.shardkeep_node_id) {
      await attemptWalletRecovery();
    }

    // If Sentry is enabled, start heartbeat
    if (sentryEnabled) {
      startHeartbeat();
    }
  } catch (e) {
    console.error('[ShardKeep] Init failed:', e.message);
  }
}

/**
 * Attempt to recover a previous node identity via wallet signature.
 * Called when extension storage was wiped (no stored node_id) but a wallet
 * may still be connected. If the wallet was previously linked to a node,
 * the server returns the old node_id and a fresh API key.
 */
async function attemptWalletRecovery() {
  try {
    const walletData = await chrome.storage.local.get(['walletPubkey']);
    const sigData = await chrome.storage.session.get(['walletSignature']);

    if (!walletData.walletPubkey || !sigData.walletSignature) {
      console.log('[ShardKeep] No wallet connected — skipping recovery');
      return false;
    }

    console.log('[ShardKeep] Attempting wallet-based node recovery...');

    const resp = await fetch(RECOVER_URL, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        wallet_pubkey: walletData.walletPubkey,
        signature: sigData.walletSignature,
        current_node_id: nodeId,
      }),
    });

    if (!resp.ok) {
      console.warn(`[ShardKeep] Recovery request failed: HTTP ${resp.status}`);
      return false;
    }

    const data = await resp.json();

    if (data.recovered) {
      const oldNodeId = nodeId;
      nodeId = data.node_id;
      apiKey = data.api_key;

      await chrome.storage.local.set({
        shardkeep_node_id: nodeId,
        shardkeep_api_key: apiKey,
      });

      console.log(`[ShardKeep] Identity RECOVERED: ${oldNodeId} → ${nodeId} (${data.total_heartbeats} heartbeats restored)`);
      return true;
    } else {
      console.log(`[ShardKeep] Recovery: ${data.message || 'no previous node found'}`);
      return false;
    }
  } catch (err) {
    console.warn('[ShardKeep] Recovery attempt failed:', err.message);
    return false;
  }
}

// ─── Sentry Toggle ───
async function enableSentry() {
  sentryEnabled = true;
  await chrome.storage.local.set({ shardkeep_sentry_enabled: true });
  startHeartbeat();
  // Send immediate heartbeat
  await sendHeartbeat();
  console.log('[ShardKeep] Sentry ENABLED — heartbeats started');
}

async function disableSentry() {
  sentryEnabled = false;
  await chrome.storage.local.set({ shardkeep_sentry_enabled: false });
  if (chrome.alarms) chrome.alarms.clear('shardkeep-heartbeat');
  console.log('[ShardKeep] Sentry DISABLED — heartbeats stopped');
}

function startHeartbeat() {
  if (chrome.alarms) {
    chrome.alarms.create('shardkeep-heartbeat', { periodInMinutes: HEARTBEAT_INTERVAL_MIN });
    console.log('[ShardKeep] Heartbeat alarm set');
  } else {
    console.log('[ShardKeep] Heartbeat using setInterval fallback');
  }
}

// ─── Alarm Handler ───
if (chrome.alarms) {
  chrome.alarms.onAlarm.addListener((alarm) => {
    if (alarm.name === 'shardkeep-heartbeat') {
      if (sentryEnabled) {
        sendHeartbeat();
      }
      checkVersion();
    }
  });
} else {
  console.warn('[ShardKeep] chrome.alarms not available — using setInterval fallback');
  setInterval(() => {
    if (sentryEnabled) sendHeartbeat();
    checkVersion();
  }, HEARTBEAT_INTERVAL_MIN * 60 * 1000);
}

// ─── Heartbeat (Sentry) ───
async function sendHeartbeat() {
  if (!sentryEnabled) return;

  try {
    // Calculate shard storage usage
    const shardData = await chrome.storage.local.get(['shardkeep_shards']);
    const shards = shardData.shardkeep_shards || {};
    const shardCount = Object.keys(shards).length;
    const shardBytes = JSON.stringify(shards).length;

    // Get wallet address for node label
    const walletData = await chrome.storage.local.get(['walletPubkey']);
    const walletAddr = walletData.walletPubkey || 'Unknown';
    const shortAddr = walletAddr.length > 8 ? walletAddr.slice(0, 4) + '...' + walletAddr.slice(-4) : walletAddr;
    const chromeVer = (navigator.userAgent.match(/Chrome\/(\d+)/) || ['', '?'])[1];
    const nodeLabel = shortAddr + ' - CHR' + chromeVer;

    const payload = {
      node_id: nodeId,
      // Full operator wallet — lets heartbeat.php's sentry dedup defense
      // (2026-05-15) fire: a fresh node_id for a wallet that already has a
      // sentry row is told to adopt the canonical id instead of forking a
      // duplicate. Previously omitted, so the dedup silently no-op'd for
      // browser sentries and every storage wipe / Chrome update spawned a dup.
      wallet_address: walletData.walletPubkey || null,
      node_type: NODE_TYPE,
      network: NETWORK,
      version: SENTRY_VERSION,
      timestamp: new Date().toISOString(),
      system: {
        hostname: nodeLabel,
        os: navigator.platform || 'unknown',
        arch: 'browser',
        cpu_cores: navigator.hardwareConcurrency || 0,
        memory_total_mb: Math.round((navigator.deviceMemory || 0) * 1024),
        memory_used_pct: 0,
        disk_total_gb: 0,
        disk_used_pct: Math.round((shardBytes / SHARD_STORAGE_LIMIT) * 100),
        uptime_hours: 0,
        load_1m: 0,
        ip_address: 'browser',
        shard_count: shardCount,
        shard_bytes: shardBytes,
        shard_limit: SHARD_STORAGE_LIMIT,
      },
    };

    // Include verify result from previous task
    if (pendingVerifyResult) {
      payload.verify_result = pendingVerifyResult;
      pendingVerifyResult = null;
    }

    const headers = { 'Content-Type': 'application/json' };
    if (apiKey) {
      headers['X-API-Key'] = apiKey;
    }

    const resp = await fetch(HEARTBEAT_URL, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });

    if (!resp.ok) {
      console.warn(`[ShardKeep] Heartbeat failed: HTTP ${resp.status}`);
      return;
    }

    const data = await resp.json();

    // Server-side dedup: the aggregator detected we're a fresh node_id for
    // a wallet that already has a registered sentry row. Adopt the canonical
    // id locally so the next heartbeat continues that node's history instead
    // of forking a duplicate. (See heartbeat.php "Sentry dedup defense".)
    if (data.adopt_node_id && data.adopt_node_id !== nodeId) {
      console.log(`[ShardKeep] Adopting canonical node_id: ${nodeId} → ${data.adopt_node_id}`);
      nodeId = data.adopt_node_id;
      await chrome.storage.local.set({ shardkeep_node_id: nodeId });
      // Drop any stale API key — it belonged to the throw-away identity.
      apiKey = null;
      await chrome.storage.local.remove(['shardkeep_api_key']);
      // Skip the rest of this cycle; next heartbeat will use the adopted id.
      return;
    }

    // Handle API key receipt
    if (data.api_key) {
      apiKey = data.api_key;
      await chrome.storage.local.set({ shardkeep_api_key: apiKey });
      console.log('[ShardKeep] API key received');
    }

    // Handle commands
    if (data.commands) {
      for (const cmd of data.commands) {
        console.log(`[ShardKeep] Command: ${cmd.type}`);
      }
    }

    // Handle Sentry verification task
    if (data.verify_task) {
      const vtask = data.verify_task;
      console.log(`[ShardKeep] Verify task: ${vtask.task_id} for shard ${vtask.shard_id}`);
      try {
        const vresp = await fetch(HEARTBEAT_URL.replace('heartbeat.php', 'shards.php'), {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ action: 'sentry-verify', task_id: vtask.task_id, shard_id: vtask.shard_id }),
        });
        const vresult = await vresp.json();
        pendingVerifyResult = { task_id: vtask.task_id, passed: vresult.bastion_passed, latency_ms: vresult.latency_ms };
        console.log(`[ShardKeep] Verify complete: responded=${vresult.bastion_responded}, passed=${vresult.bastion_passed}`);
      } catch (verr) {
        console.error('[ShardKeep] Verify task failed:', verr.message);
        pendingVerifyResult = { task_id: vtask.task_id, error: verr.message };
      }
    }

    // Store heartbeat result for popup
    await chrome.storage.local.set({
      shardkeep_heartbeat: {
        ok: true,
        heartbeat: data.heartbeat,
        qualification_status: data.qualification_status,
        network: data.network,
        shard_count: shardCount,
        shard_bytes: shardBytes,
        shard_pct: Math.round((shardBytes / SHARD_STORAGE_LIMIT) * 100),
        timestamp: new Date().toISOString(),
      }
    });

    console.log(`[ShardKeep] Heartbeat #${data.heartbeat} OK [${data.qualification_status}]`);

  } catch (err) {
    console.error('[ShardKeep] Heartbeat error:', err.message);
  }
}

// ─── Version Check ───
async function checkVersion() {
  try {
    // Build wallet-based label for registration
    const walletData = await chrome.storage.local.get(['walletPubkey']);
    const walletAddr = walletData.walletPubkey || 'Unknown';
    const shortAddr = walletAddr.length > 8 ? walletAddr.slice(0, 4) + '...' + walletAddr.slice(-4) : walletAddr;
    const chromeVer = (navigator.userAgent.match(/Chrome\/(\d+)/) || ['', '?'])[1];

    const payload = {
      node_id: nodeId,
      wallet_version: WALLET_VERSION,
      sentry_version: SENTRY_VERSION,
      wallet_address: walletAddr,
      platform: navigator.platform || 'unknown',
      browser: 'chrome',
      hostname: shortAddr + ' - CHR' + chromeVer,
    };

    const headers = { 'Content-Type': 'application/json' };
    if (apiKey) {
      headers['X-API-Key'] = apiKey;
    }

    const resp = await fetch(OPERATOR_URL, {
      method: 'POST',
      headers,
      body: JSON.stringify(payload),
    });

    if (!resp.ok) return;

    const data = await resp.json();

    if (data.api_key) {
      apiKey = data.api_key;
      await chrome.storage.local.set({ shardkeep_api_key: apiKey });
    }

    await chrome.storage.local.set({
      shardkeep_version_check: {
        wallet_version: WALLET_VERSION,
        server_wallet_version: data.wallet_version,
        server_sentry_version: data.sentry_version,
        wallet_update_available: data.wallet_update_available,
        sentry_update_available: data.sentry_update_available,
        wallet_download_url: data.wallet_download_url,
        reward_eligible: data.reward_eligible,
        qualification_status: data.qualification_status,
        node_id: nodeId,
        checked_at: new Date().toISOString(),
      }
    });

  } catch (err) {
    console.error('[ShardKeep] Version check error:', err.message);
  }
}

// ─── Message Handling ───
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  switch (message.type) {
    case 'GET_VAULT_STATUS':
      chrome.storage.local.get(['walletPubkey', 'shardkeep_version_check', 'shardkeep_node_id', 'shardkeep_sentry_enabled', 'shardkeep_heartbeat'], (result) => {
        sendResponse({
          connected: !!result.walletPubkey,
          address: result.walletPubkey || null,
          versionCheck: result.shardkeep_version_check || null,
          nodeId: result.shardkeep_node_id || null,
          sentryEnabled: !!result.shardkeep_sentry_enabled,
          heartbeat: result.shardkeep_heartbeat || null,
        });
      });
      return true;

    case 'GET_VERSION_CHECK':
      chrome.storage.local.get(['shardkeep_version_check'], (result) => {
        sendResponse(result.shardkeep_version_check || null);
      });
      return true;

    case 'FORCE_VERSION_CHECK':
      checkVersion().then(() => {
        chrome.storage.local.get(['shardkeep_version_check'], (result) => {
          sendResponse(result.shardkeep_version_check || null);
        });
      });
      return true;

    case 'ENABLE_SENTRY':
      enableSentry().then(() => {
        sendResponse({ ok: true, enabled: true });
      });
      return true;

    case 'DISABLE_SENTRY':
      disableSentry().then(() => {
        sendResponse({ ok: true, enabled: false });
      });
      return true;

    case 'GET_SENTRY_STATUS':
      chrome.storage.local.get(['shardkeep_sentry_enabled', 'shardkeep_heartbeat'], (result) => {
        sendResponse({
          enabled: !!result.shardkeep_sentry_enabled,
          heartbeat: result.shardkeep_heartbeat || null,
        });
      });
      return true;

    case 'FILL_CREDENTIALS':
      chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
        if (tabs[0]) {
          chrome.tabs.sendMessage(tabs[0].id, {
            type: 'FILL',
            username: message.username,
            password: message.password
          });
        }
      });
      sendResponse({ ok: true });
      return false;

    case 'GET_TEAM_VAULT_UNLOCK':
      // Material the popup needs to read Shared Vaults:
      //   walletPubkey        → wallet_address
      //   walletSignature     → read-auth (the "unlock vault" sig; server re-verifies)
      //   teamVaultSignature  → derives the MEK-wrap KEK client-side (never sent)
      Promise.all([
        chrome.storage.local.get(['walletPubkey']),
        chrome.storage.session.get(['walletSignature', 'teamVaultSignature', 'teamVaultPubkey']),
      ]).then(([local, session]) => {
        sendResponse({
          pubkey: local.walletPubkey || null,
          walletSignature: session.walletSignature || null,
          teamVaultSignature: session.teamVaultSignature || null,
          teamVaultUnlocked: !!session.teamVaultSignature && session.teamVaultPubkey === local.walletPubkey,
        });
      });
      return true;

    case 'CLEAR_TEAM_VAULT_UNLOCK':
      chrome.storage.session.remove(['teamVaultSignature', 'teamVaultPubkey']).then(() => sendResponse({ ok: true }));
      return true;

    case 'DISCONNECT':
      // Clear wallet identity AND the in-session signature
      Promise.all([
        chrome.storage.local.remove(['walletPubkey', 'walletName', 'walletConnectedAt']),
        chrome.storage.session.remove(['walletSignature', 'walletMapSignature', 'teamVaultSignature', 'teamVaultPubkey']),
      ]).then(() => sendResponse({ ok: true }));
      return true;

    default:
      return false;
  }
});

console.log('[ShardKeep] Background worker v' + WALLET_VERSION + ' started');
